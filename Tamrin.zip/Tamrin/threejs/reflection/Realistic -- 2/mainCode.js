let scene, camera, renderer, sphereCamera;
var cone;
function init() {
    //? Main setup
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(70, window.innerWidth / window.innerHeight, 1, 5000);
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    //? Camera 
    camera.position.set(0, 400, 1500);
    //! 500 is the resolution
    sphereCamera = new THREE.CubeCamera(1, 1000, 500);
    sphereCamera.position.set(0, 100, 0);
    scene.add(sphereCamera);



    // Mercury sphere
    var geometry = new THREE.ConeGeometry(340, 500, 50);
    var material = new THREE.MeshBasicMaterial({
        envMap: sphereCamera.renderTarget
    });
    cone = new THREE.Mesh(geometry, material);
    cone.position.set(5, 520, 0);
    scene.add(cone);

    var geometry = new THREE.BoxGeometry(550, 550, 550);
    var material = new THREE.MeshBasicMaterial({
        envMap: sphereCamera.renderTarget
    });
    cone = new THREE.Mesh(geometry, material);
    cone.position.set(0, -8, 0);
    scene.add(cone);





    //? Setup background
    let urls = [
        'texture/posx.jpg', 'texture/negx.jpg',
        'texture/posy.jpg', 'texture/negy.jpg',
        'texture/posz.jpg', 'texture/negz.jpg'
    ];

    let loader = new THREE.CubeTextureLoader();
    scene.background = loader.load(urls);
    let controls = new THREE.OrbitControls(camera, renderer.domElement);
    controls.enableZoom = false;
    render();
};

function render() {
    renderer.render(scene, camera);
    sphereCamera.updateCubeMap(renderer, scene);
    requestAnimationFrame(render);
};
init();