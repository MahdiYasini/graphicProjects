var scene, camera, renderer;
var cylinder;
init();
animate();
var xpos = 0;
var zpos = 0;
window.addEventListener('keydown', onDocumentKeyDown, false);
function onDocumentKeyDown(event) {
    // up
    if (event.keyCode == 87) {
        zpos += 1;
        // down
    } else if (event.keyCode == 83) {
        zpos -= 1;
        // left
    } else if (event.keyCode == 65) {
        xpos -= 1;
        // right
    } else if (event.keyCode == 68) {
        xpos += 1;
    }
};

// once everything is loaded, we run our Three.js stuff.
function init() {
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(45, window.innerWidth / window.innerHeight, 0.1, 1000);
    renderer = new THREE.WebGLRenderer({ antialias: true });
    renderer.setClearColor(new THREE.Color(0xffffcc));
    renderer.setSize(window.innerWidth, window.innerHeight);
    //Add Sound 
    var listener = new THREE.AudioListener();
    camera.add(listener);

    // create the PositionalAudio object (passing in the listener)
    var sound = new THREE.PositionalAudio(listener);

    // load a sound and set it as the PositionalAudio object's buffer
    var audioLoader = new THREE.AudioLoader();
    audioLoader.load('sounds/Me.mp3', function (buffer) {
        sound.setBuffer(buffer);
        sound.setRefDistance(20);
        // sound.play();
    });
    //Light
    var spotLight = new THREE.SpotLight(0xAA5667);
    spotLight.angle = 0.8;
    spotLight.penumbra = 0.05;
    spotLight.position.set(0, 60, 20);
    scene.add(spotLight.clone());
    // cylinder sphere




    
    var Texture = THREE.ImageUtils.loadTexture("texture/poster2.jpg");
    var geometry = new THREE.CylinderGeometry(5, 5, 20, 32);
    var material = new THREE.MeshBasicMaterial({
        map: Texture,
        shininess: 0.5,
        specular: 0xffffff,
        shading: THREE.SmoothShading
    });
    cylinder = new THREE.Mesh(geometry, material);
    cylinder.position.y = -30;
    // cylinder.add( sound );
    scene.add(cylinder);
    //Surface
    var Texture2 = THREE.ImageUtils.loadTexture("texture/poster.jpg");
    var surfaceGeometry = new THREE.PlaneGeometry(300, 300);
    var surfaceMaterial = new THREE.MeshBasicMaterial({
        map: Texture2,
        shininess: 0.5,
        specular: 0xffffff,
        shading: THREE.SmoothShading, side: THREE.DoubleSide
    });
    var surfaceMesh = new THREE.Mesh(surfaceGeometry, surfaceMaterial);
    surfaceMesh.rotateX(Math.PI / 2);
    surfaceMesh.position.y = -50;
    scene.add(surfaceMesh);
    // Camera
    camera.position.set(30, 90, 170);
    camera.lookAt(scene.position);
    // add the output of the renderer to the html element
    document.getElementById("WebGL-output").appendChild(renderer.domElement);
};
function animate() {
    renderer.render(scene, camera);
    requestAnimationFrame(animate);
    cylinder.position.x = 0 + xpos;
    cylinder.position.z = 0 - zpos;
};